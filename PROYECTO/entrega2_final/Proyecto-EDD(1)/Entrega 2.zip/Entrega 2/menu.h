#include <iostream>
#include <vector>

class menu {
  public:
    static void printWelcome();
    static void printMenu ();
};