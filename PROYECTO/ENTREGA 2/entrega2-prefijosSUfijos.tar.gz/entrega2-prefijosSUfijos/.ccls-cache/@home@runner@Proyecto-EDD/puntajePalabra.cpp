#include "puntajePalabra.h"
#include <iostream>

int puntajePalabra::puntaje(std::string palabra) {
  
  return 10;
}