#include <iostream>
#include <vector>

class ayuda {
  public:
  static void printAyudaVacio();
  static void printAyudaComando(std::string comando);
};