#include <iostream>

class controlador_juego {
  public:
    static bool vLetras (std::string letras_jugador);
    static bool vComando(std::string comando);
};