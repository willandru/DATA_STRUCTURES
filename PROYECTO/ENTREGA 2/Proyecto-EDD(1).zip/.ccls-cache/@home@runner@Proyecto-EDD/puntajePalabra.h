#include <iostream>
#include <vector>

class puntajePalabra {
  public:
  static int puntaje(std::string palabra);
};